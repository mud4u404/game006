/**
 * 端到端冒烟测试：用无头 Chromium 从标题画面一路玩到第一回首领战。
 * 用法：先 npm run build && npm run preview，再运行 node scripts/smoke.mjs [网址] [截图目录]
 * 需要本机装有 playwright（npm i -D playwright 或全局安装）。
 */
import { createRequire } from 'node:module';
import { execSync } from 'node:child_process';
const require = createRequire(import.meta.url);
let pw;
try { pw = require('playwright'); } catch { pw = require(execSync('npm root -g').toString().trim() + '/playwright'); }

const url = process.argv[2] || 'http://localhost:4173/';
const shots = process.argv[3];
const b = await pw.chromium.launch();
const p = await b.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
const errs = [];
p.on('pageerror', e => errs.push(e.message));
await p.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
await p.goto(url);
await p.evaluate(() => localStorage.clear());
await p.reload();
const click = async sel => { await p.waitForSelector(sel, { timeout: 8000 }); await p.click(sel); };
const snap = async name => { if (shots) await p.screenshot({ path: `${shots}/${name}.png` }); };
const log = (...a) => console.log('·', ...a);

await snap('01-title');
await click('[data-act="tGo:new"]');
await click('[data-act="stPick:0"]');                 // 回想
for (let i = 0; i < 3; i++) { await click(`[data-act="stPick:${i}"]`); await click('[data-act="stNext"]'); }
await snap('02-name');
await p.fill('#nameIn', '听雨');
await click('[data-act="stPick:0"]');
await click('[data-act="stPick:0"]');                 // 回到小屋
log('序章开场完成', await p.textContent('.who b'));
await snap('03-guazhou');
await click('[data-act="do:交谈"]');                  // 江伯
await click('[data-act="quest"]');                    // 去瓜洲镇
await p.waitForTimeout(1200);
await click('[data-act="sel:huichun"]');
await click('[data-act="do:抓药"]');
await click('[data-act="quest"]');                    // 回小屋，触发夜袭
await p.waitForTimeout(1200);
await click('[data-act="stPick:0"]');                 // 拔剑迎敌

async function fight(tag, pickBest = true) {
  for (let i = 0; i < 500; i++) {
    await p.waitForTimeout(200);
    if (!(await p.$('#fightLayer:not([hidden])'))) return 'closed';
    if (await p.$('#sheetLayer:not([hidden]) [data-act="fResult"]')) return 'result';
    if (await p.$('#fsheet.alert')) {
      const opts = await p.$$eval('.ropt', els => els.map(e => ({ act: e.dataset.act, dis: e.disabled, o: e.querySelector('.ro').textContent })));
      const live = opts.filter(o => !o.dis);
      const order = '一两三四五六七八九';
      const choice = pickBest ? live.sort((a, c) => order.indexOf(c.o[2]) - order.indexOf(a.o[2]))[0] : live[0];
      if (tag && !(await p.$('#rTip[hidden]'))) await snap(`${tag}-tutorial`);
      await p.click(`[data-act="${choice.act}"]`).catch(() => {});
      continue;
    }
    if (await p.$('#opening:not([hidden])')) { await p.click('#opening').catch(() => {}); continue; }
    for (const s of ['#skUlt', '#skGu', '#skJh']) { const el = await p.$(s + ':not([disabled])'); if (el) { await el.click().catch(() => {}); break; } }
  }
  return 'timeout';
}

log('黑衣人', await fight('04-fight1'));
await click('[data-act="stPick:0"]');                 // 握紧长剑
log('黑衣首领', await fight('05-fight2'));
await p.waitForSelector('#storyLayer:not([hidden])');
await snap('06-death');
await click('[data-act="stPick:0"]');                 // 江伯——
await click('[data-act="stPick:0"]');                 // 掩埋江伯
await click('[data-act="stPick:0"]');                 // 登船
await p.waitForTimeout(500);
await snap('07-chapter');
await click('[data-act="chapDone"]');
log('到达', await p.textContent('#appbar h1'), '| 主线：', await p.textContent('.quest .qt'));
await snap('08-yangzhou');
await click('[data-act="quest"]');                    // 去大明寺
await p.waitForTimeout(1200);
await click('[data-act="sel:liaochen"]');
await click('[data-act="do:交谈"]');
log('了尘：', (await p.textContent('.reply')).slice(0, 24));
await click('[data-act="quest"]');                    // 去渡口
await p.waitForTimeout(2000);
await click('[data-act="sel:tu"]');
await click('[data-act="do:动手"]');
log('屠千山', await fight(null));
log('结算：', (await p.textContent('#sheetLayer .r-h')).trim());
await snap('09-result');
console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no page errors');
await b.close();
